from django.contrib import admin
from .models import Todolist, Item




admin.site.register(Todolist)

