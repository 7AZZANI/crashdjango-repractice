from django import forms 


class CreateNewList(forms.Form):
    name = forms.CharField(label="name", max_length=30, required=True)
    check = forms.BooleanField()
    age = forms.IntegerField()